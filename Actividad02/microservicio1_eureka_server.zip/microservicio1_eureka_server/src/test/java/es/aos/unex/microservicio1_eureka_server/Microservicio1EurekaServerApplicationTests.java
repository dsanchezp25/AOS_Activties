package es.aos.unex.microservicio1_eureka_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Microservicio1EurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
