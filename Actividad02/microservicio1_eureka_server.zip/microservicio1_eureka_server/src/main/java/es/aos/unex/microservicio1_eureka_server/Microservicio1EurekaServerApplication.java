package es.aos.unex.microservicio1_eureka_server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Microservicio1EurekaServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(Microservicio1EurekaServerApplication.class, args);
	}

}
