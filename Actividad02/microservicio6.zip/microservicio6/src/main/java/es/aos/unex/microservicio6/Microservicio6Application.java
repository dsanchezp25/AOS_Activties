package es.aos.unex.microservicio6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Microservicio6Application {

	public static void main(String[] args) {
		SpringApplication.run(Microservicio6Application.class, args);
	}

}
