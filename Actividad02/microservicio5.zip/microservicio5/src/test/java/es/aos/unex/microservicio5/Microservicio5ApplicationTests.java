package es.aos.unex.microservicio5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Microservicio5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
